/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
int main()
{
    cout<<"\n\t\t V E H I C L E   P A R K I N G"<<endl<<endl;
    int enter;
    int car=0, bike=0, rikshaw=0;
      while(true)
      {
          cout<<"Press 1 to enter car"<<endl;
          cout<<"Press 2 to enter bike"<<endl;
          cout<<"Press 3 to enter rikshaw"<<endl;
          cout<<"Press 4 to show the record"<<endl;
          cout<<"Press 5 to delete the record"<<endl;
          cout<<"Press 6 to exit"<<endl;
          cin>>enter;
          if(enter==1)
          {
              car++;
              cout<<"car is added"<<endl;
              
          }
          else if(enter==2)
          {
              bike++;
              cout<<"bike is added"<<endl;
          }
          else if(enter==3)
          {
              rikshaw++;
              cout<<"rikshaw is added"<<endl;
              
          }
          else if(enter==4)
          {
              cout<<" \n_-_-_-DATA-_-_-_"<<endl;
              cout<<"CAR:"<<car<<endl;
              cout<<"BIKE:"<<bike<<endl;
              cout<<"RIKSHAW:"<<rikshaw<<endl;
             
          }
          else if(enter==5)
          {
              car=0;
              bike=0;
              rikshaw=0;
              cout<<"\n Your record is deleted "<<endl<<endl;
              
          }
         else if(enter==6)
          {
              exit(0);
          }
      }
}